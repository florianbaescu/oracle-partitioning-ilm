-- =============================================================================
-- Table Migration Analysis Package
-- Analyzes tables and recommends optimal partitioning strategies
-- =============================================================================

CREATE OR REPLACE PACKAGE dwh_table_migration_analyzer AS
    -- Main analysis procedures
    PROCEDURE analyze_table(
        p_task_id NUMBER
    );

    PROCEDURE analyze_all_pending_tasks(
        p_project_id NUMBER DEFAULT NULL
    );

    -- Analysis helper functions
    FUNCTION recommend_partition_strategy(
        p_owner VARCHAR2,
        p_table_name VARCHAR2,
        p_reason OUT VARCHAR2
    ) RETURN VARCHAR2;

    FUNCTION estimate_partition_count(
        p_owner VARCHAR2,
        p_table_name VARCHAR2,
        p_partition_key VARCHAR2,
        p_partition_type VARCHAR2
    ) RETURN NUMBER;

    FUNCTION calculate_complexity_score(
        p_owner VARCHAR2,
        p_table_name VARCHAR2
    ) RETURN NUMBER;

    -- Data distribution analysis
    PROCEDURE analyze_column_distribution(
        p_owner VARCHAR2,
        p_table_name VARCHAR2,
        p_column_name VARCHAR2,
        p_distinct_values OUT NUMBER,
        p_null_percentage OUT NUMBER,
        p_distribution_type OUT VARCHAR2
    );

    -- Dependency analysis
    FUNCTION get_dependent_objects(
        p_owner VARCHAR2,
        p_table_name VARCHAR2
    ) RETURN CLOB;

    FUNCTION identify_blocking_issues(
        p_owner VARCHAR2,
        p_table_name VARCHAR2
    ) RETURN CLOB;

END dwh_table_migration_analyzer;
/

CREATE OR REPLACE PACKAGE BODY dwh_table_migration_analyzer AS

    -- ==========================================================================
    -- Private Helper Functions
    -- ==========================================================================

    FUNCTION get_date_columns(
        p_owner VARCHAR2,
        p_table_name VARCHAR2
    ) RETURN SYS.ODCIVARCHAR2LIST
    AS
        v_columns SYS.ODCIVARCHAR2LIST := SYS.ODCIVARCHAR2LIST();
    BEGIN
        SELECT column_name
        BULK COLLECT INTO v_columns
        FROM all_tab_columns
        WHERE owner = p_owner
        AND table_name = p_table_name
        AND data_type IN ('DATE', 'TIMESTAMP', 'TIMESTAMP(6)')
        ORDER BY column_id;

        RETURN v_columns;
    END get_date_columns;


    FUNCTION analyze_date_column(
        p_owner VARCHAR2,
        p_table_name VARCHAR2,
        p_column_name VARCHAR2,
        p_min_date OUT DATE,
        p_max_date OUT DATE,
        p_range_days OUT NUMBER
    ) RETURN BOOLEAN
    AS
        v_sql VARCHAR2(4000);
        v_count NUMBER;
    BEGIN
        -- Check if column has data
        v_sql := 'SELECT COUNT(*) FROM ' || p_owner || '.' || p_table_name ||
                ' WHERE ' || p_column_name || ' IS NOT NULL';

        EXECUTE IMMEDIATE v_sql INTO v_count;

        IF v_count = 0 THEN
            RETURN FALSE;
        END IF;

        -- Get date range
        v_sql := 'SELECT MIN(' || p_column_name || '), MAX(' || p_column_name || ')' ||
                ' FROM ' || p_owner || '.' || p_table_name;

        EXECUTE IMMEDIATE v_sql INTO p_min_date, p_max_date;

        IF p_min_date IS NOT NULL AND p_max_date IS NOT NULL THEN
            p_range_days := p_max_date - p_min_date;
            RETURN TRUE;
        END IF;

        RETURN FALSE;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN FALSE;
    END analyze_date_column;


    FUNCTION detect_scd2_pattern(
        p_owner VARCHAR2,
        p_table_name VARCHAR2,
        p_scd2_type OUT VARCHAR2,
        p_date_column OUT VARCHAR2
    ) RETURN BOOLEAN
    AS
        v_has_effective_date BOOLEAN := FALSE;
        v_has_valid_from BOOLEAN := FALSE;
        v_has_valid_to BOOLEAN := FALSE;
        v_has_current_flag BOOLEAN := FALSE;
        v_has_is_current BOOLEAN := FALSE;
    BEGIN
        -- Check for effective_date pattern
        SELECT COUNT(*) INTO v_has_effective_date
        FROM (
            SELECT 1 FROM all_tab_columns
            WHERE owner = p_owner
            AND table_name = p_table_name
            AND UPPER(column_name) IN ('EFFECTIVE_DATE', 'EFF_DATE', 'START_DATE')
            AND data_type IN ('DATE', 'TIMESTAMP')
            FETCH FIRST 1 ROW ONLY
        );

        SELECT COUNT(*) INTO v_has_current_flag
        FROM (
            SELECT 1 FROM all_tab_columns
            WHERE owner = p_owner
            AND table_name = p_table_name
            AND UPPER(column_name) IN ('CURRENT_FLAG', 'IS_CURRENT', 'CURRENT_IND')
            FETCH FIRST 1 ROW ONLY
        );

        -- Check for valid_from/valid_to pattern
        SELECT COUNT(*) INTO v_has_valid_from
        FROM (
            SELECT 1 FROM all_tab_columns
            WHERE owner = p_owner
            AND table_name = p_table_name
            AND UPPER(column_name) IN ('VALID_FROM_DTTM', 'VALID_FROM', 'START_DTTM', 'BEGIN_DTTM')
            AND data_type IN ('DATE', 'TIMESTAMP', 'TIMESTAMP(6)')
            FETCH FIRST 1 ROW ONLY
        );

        SELECT COUNT(*) INTO v_has_valid_to
        FROM (
            SELECT 1 FROM all_tab_columns
            WHERE owner = p_owner
            AND table_name = p_table_name
            AND UPPER(column_name) IN ('VALID_TO_DTTM', 'VALID_TO', 'END_DTTM', 'EXPIRY_DTTM')
            AND data_type IN ('DATE', 'TIMESTAMP', 'TIMESTAMP(6)')
            FETCH FIRST 1 ROW ONLY
        );

        -- Determine SCD2 type
        IF v_has_effective_date > 0 AND v_has_current_flag > 0 THEN
            p_scd2_type := 'EFFECTIVE_DATE';
            -- Get actual column name
            SELECT column_name INTO p_date_column
            FROM all_tab_columns
            WHERE owner = p_owner
            AND table_name = p_table_name
            AND UPPER(column_name) IN ('EFFECTIVE_DATE', 'EFF_DATE', 'START_DATE')
            AND data_type IN ('DATE', 'TIMESTAMP')
            FETCH FIRST 1 ROW ONLY;
            RETURN TRUE;

        ELSIF v_has_valid_from > 0 AND v_has_valid_to > 0 THEN
            p_scd2_type := 'VALID_FROM_TO';
            -- Get actual column name
            SELECT column_name INTO p_date_column
            FROM all_tab_columns
            WHERE owner = p_owner
            AND table_name = p_table_name
            AND UPPER(column_name) IN ('VALID_FROM_DTTM', 'VALID_FROM', 'START_DTTM', 'BEGIN_DTTM')
            AND data_type IN ('DATE', 'TIMESTAMP', 'TIMESTAMP(6)')
            FETCH FIRST 1 ROW ONLY;
            RETURN TRUE;
        END IF;

        RETURN FALSE;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN FALSE;
    END detect_scd2_pattern;


    FUNCTION detect_events_table(
        p_owner VARCHAR2,
        p_table_name VARCHAR2,
        p_event_column OUT VARCHAR2
    ) RETURN BOOLEAN
    AS
        v_count NUMBER;
    BEGIN
        -- Check for event-related column patterns
        SELECT COUNT(*) INTO v_count
        FROM all_tab_columns
        WHERE owner = p_owner
        AND table_name = p_table_name
        AND (
            UPPER(column_name) IN ('EVENT_DTTM', 'EVENT_TIMESTAMP', 'EVENT_DATE', 'EVENT_TIME', 'AUDIT_DTTM', 'CAPTURE_DTTM', 'INGESTION_DTTM')
            OR UPPER(table_name) LIKE '%EVENT%'
            OR UPPER(table_name) LIKE '%AUDIT%'
            OR UPPER(table_name) LIKE '%LOG%'
        );

        IF v_count > 0 THEN
            -- Try to find the event timestamp column
            BEGIN
                SELECT column_name INTO p_event_column
                FROM all_tab_columns
                WHERE owner = p_owner
                AND table_name = p_table_name
                AND UPPER(column_name) IN ('EVENT_DTTM', 'EVENT_TIMESTAMP', 'EVENT_DATE', 'AUDIT_DTTM', 'CAPTURE_DTTM', 'INGESTION_DTTM', 'CREATED_DTTM', 'INSERT_DTTM')
                AND data_type IN ('DATE', 'TIMESTAMP', 'TIMESTAMP(6)')
                ORDER BY
                    CASE UPPER(column_name)
                        WHEN 'EVENT_DTTM' THEN 1
                        WHEN 'EVENT_TIMESTAMP' THEN 2
                        WHEN 'AUDIT_DTTM' THEN 3
                        WHEN 'CAPTURE_DTTM' THEN 4
                        ELSE 5
                    END
                FETCH FIRST 1 ROW ONLY;

                RETURN TRUE;
            EXCEPTION
                WHEN NO_DATA_FOUND THEN
                    RETURN FALSE;
            END;
        END IF;

        RETURN FALSE;
    END detect_events_table;


    -- Detect date-like columns stored as NUMBER (YYYYMMDD, Unix timestamp, etc.)
    FUNCTION detect_numeric_date_column(
        p_owner VARCHAR2,
        p_table_name VARCHAR2,
        p_date_column OUT VARCHAR2,
        p_date_format OUT VARCHAR2
    ) RETURN BOOLEAN
    AS
        v_count NUMBER;
        v_sample_value NUMBER;
        v_sql VARCHAR2(4000);
        v_min_val NUMBER;
        v_max_val NUMBER;
    BEGIN
        -- Look for columns with date-like names that are NUMBER type
        FOR rec IN (
            SELECT column_name, data_type, data_length, data_precision
            FROM all_tab_columns
            WHERE owner = p_owner
            AND table_name = p_table_name
            AND data_type = 'NUMBER'
            AND (
                UPPER(column_name) LIKE '%DATE%'
                OR UPPER(column_name) LIKE '%TIME%'
                OR UPPER(column_name) LIKE '%DTTM%'
                OR UPPER(column_name) LIKE '%TIMESTAMP%'
                OR UPPER(column_name) LIKE '%DT'
                OR UPPER(column_name) IN ('EFFECTIVE_DT', 'VALID_FROM', 'VALID_TO', 'START_DT', 'END_DT')
            )
        ) LOOP
            -- Sample the column to detect format
            BEGIN
                v_sql := 'SELECT MIN(' || rec.column_name || '), MAX(' || rec.column_name || '), ' ||
                         'COUNT(*) FROM ' || p_owner || '.' || p_table_name ||
                         ' WHERE ' || rec.column_name || ' IS NOT NULL AND ROWNUM <= 1000';

                EXECUTE IMMEDIATE v_sql INTO v_min_val, v_max_val, v_count;

                IF v_count > 0 THEN
                    -- Check for YYYYMMDD format (8 digits, values between 19000101 and 21000101)
                    IF v_min_val >= 19000101 AND v_max_val <= 21001231
                       AND LENGTH(TRUNC(v_min_val)) = 8 THEN
                        p_date_column := rec.column_name;
                        p_date_format := 'YYYYMMDD';
                        RETURN TRUE;

                    -- Check for Unix timestamp (10 digits, reasonable range)
                    ELSIF v_min_val >= 946684800 AND v_max_val <= 2147483647  -- 2000-01-01 to 2038-01-19
                          AND LENGTH(TRUNC(v_min_val)) >= 10 THEN
                        p_date_column := rec.column_name;
                        p_date_format := 'UNIX_TIMESTAMP';
                        RETURN TRUE;

                    -- Check for YYMMDD format (6 digits)
                    ELSIF v_min_val >= 000101 AND v_max_val <= 991231
                          AND LENGTH(TRUNC(v_min_val)) = 6 THEN
                        p_date_column := rec.column_name;
                        p_date_format := 'YYMMDD';
                        RETURN TRUE;
                    END IF;
                END IF;
            EXCEPTION
                WHEN OTHERS THEN
                    NULL; -- Continue to next column
            END;
        END LOOP;

        RETURN FALSE;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN FALSE;
    END detect_numeric_date_column;


    -- Detect date-like columns stored as VARCHAR/CHAR
    FUNCTION detect_varchar_date_column(
        p_owner VARCHAR2,
        p_table_name VARCHAR2,
        p_date_column OUT VARCHAR2,
        p_date_format OUT VARCHAR2
    ) RETURN BOOLEAN
    AS
        v_count NUMBER;
        v_sample_value VARCHAR2(100);
        v_sql VARCHAR2(4000);
    BEGIN
        -- Look for columns with date-like names that are VARCHAR/CHAR type
        FOR rec IN (
            SELECT column_name, data_type, data_length
            FROM all_tab_columns
            WHERE owner = p_owner
            AND table_name = p_table_name
            AND data_type IN ('VARCHAR2', 'CHAR')
            AND (
                UPPER(column_name) LIKE '%DATE%'
                OR UPPER(column_name) LIKE '%TIME%'
                OR UPPER(column_name) LIKE '%DTTM%'
                OR UPPER(column_name) LIKE '%TIMESTAMP%'
                OR UPPER(column_name) LIKE '%DT'
                OR UPPER(column_name) IN ('EFFECTIVE_DT', 'VALID_FROM', 'VALID_TO', 'START_DT', 'END_DT')
            )
        ) LOOP
            -- Sample the column to detect format
            BEGIN
                v_sql := 'SELECT ' || rec.column_name || ' FROM ' || p_owner || '.' || p_table_name ||
                         ' WHERE ' || rec.column_name || ' IS NOT NULL AND ROWNUM = 1';

                EXECUTE IMMEDIATE v_sql INTO v_sample_value;

                IF v_sample_value IS NOT NULL THEN
                    -- Try various date format conversions
                    -- YYYY-MM-DD
                    BEGIN
                        EXECUTE IMMEDIATE 'SELECT COUNT(*) FROM ' || p_owner || '.' || p_table_name ||
                                        ' WHERE TO_DATE(' || rec.column_name || ', ''YYYY-MM-DD'') IS NOT NULL AND ROWNUM <= 100'
                                        INTO v_count;
                        IF v_count > 0 THEN
                            p_date_column := rec.column_name;
                            p_date_format := 'YYYY-MM-DD';
                            RETURN TRUE;
                        END IF;
                    EXCEPTION WHEN OTHERS THEN NULL;
                    END;

                    -- DD/MM/YYYY
                    BEGIN
                        EXECUTE IMMEDIATE 'SELECT COUNT(*) FROM ' || p_owner || '.' || p_table_name ||
                                        ' WHERE TO_DATE(' || rec.column_name || ', ''DD/MM/YYYY'') IS NOT NULL AND ROWNUM <= 100'
                                        INTO v_count;
                        IF v_count > 0 THEN
                            p_date_column := rec.column_name;
                            p_date_format := 'DD/MM/YYYY';
                            RETURN TRUE;
                        END IF;
                    EXCEPTION WHEN OTHERS THEN NULL;
                    END;

                    -- MM/DD/YYYY
                    BEGIN
                        EXECUTE IMMEDIATE 'SELECT COUNT(*) FROM ' || p_owner || '.' || p_table_name ||
                                        ' WHERE TO_DATE(' || rec.column_name || ', ''MM/DD/YYYY'') IS NOT NULL AND ROWNUM <= 100'
                                        INTO v_count;
                        IF v_count > 0 THEN
                            p_date_column := rec.column_name;
                            p_date_format := 'MM/DD/YYYY';
                            RETURN TRUE;
                        END IF;
                    EXCEPTION WHEN OTHERS THEN NULL;
                    END;

                    -- YYYYMMDD
                    BEGIN
                        EXECUTE IMMEDIATE 'SELECT COUNT(*) FROM ' || p_owner || '.' || p_table_name ||
                                        ' WHERE TO_DATE(' || rec.column_name || ', ''YYYYMMDD'') IS NOT NULL AND ROWNUM <= 100'
                                        INTO v_count;
                        IF v_count > 0 THEN
                            p_date_column := rec.column_name;
                            p_date_format := 'YYYYMMDD';
                            RETURN TRUE;
                        END IF;
                    EXCEPTION WHEN OTHERS THEN NULL;
                    END;

                    -- YYYY-MM-DD HH24:MI:SS
                    BEGIN
                        EXECUTE IMMEDIATE 'SELECT COUNT(*) FROM ' || p_owner || '.' || p_table_name ||
                                        ' WHERE TO_DATE(' || rec.column_name || ', ''YYYY-MM-DD HH24:MI:SS'') IS NOT NULL AND ROWNUM <= 100'
                                        INTO v_count;
                        IF v_count > 0 THEN
                            p_date_column := rec.column_name;
                            p_date_format := 'YYYY-MM-DD HH24:MI:SS';
                            RETURN TRUE;
                        END IF;
                    EXCEPTION WHEN OTHERS THEN NULL;
                    END;
                END IF;
            EXCEPTION
                WHEN OTHERS THEN
                    NULL; -- Continue to next column
            END;
        END LOOP;

        RETURN FALSE;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN FALSE;
    END detect_varchar_date_column;


    -- Generate conversion expression for non-standard date formats
    FUNCTION get_date_conversion_expr(
        p_column_name VARCHAR2,
        p_data_type VARCHAR2,
        p_date_format VARCHAR2
    ) RETURN VARCHAR2
    AS
    BEGIN
        -- Handle NUMBER-based dates
        IF p_data_type = 'NUMBER' THEN
            IF p_date_format = 'YYYYMMDD' THEN
                RETURN 'TO_DATE(TO_CHAR(' || p_column_name || '), ''YYYYMMDD'')';
            ELSIF p_date_format = 'YYMMDD' THEN
                RETURN 'TO_DATE(TO_CHAR(' || p_column_name || '), ''YYMMDD'')';
            ELSIF p_date_format = 'UNIX_TIMESTAMP' THEN
                RETURN 'TO_DATE(''1970-01-01'', ''YYYY-MM-DD'') + (' || p_column_name || ' / 86400)';
            END IF;

        -- Handle VARCHAR/CHAR-based dates
        ELSIF p_data_type IN ('VARCHAR2', 'CHAR') THEN
            RETURN 'TO_DATE(' || p_column_name || ', ''' || p_date_format || ''')';
        END IF;

        -- Default: return column as-is
        RETURN p_column_name;
    END get_date_conversion_expr;


    FUNCTION detect_staging_table(
        p_owner VARCHAR2,
        p_table_name VARCHAR2,
        p_load_column OUT VARCHAR2
    ) RETURN BOOLEAN
    AS
        v_count NUMBER;
    BEGIN
        -- Check for staging table patterns
        IF UPPER(p_table_name) LIKE 'STG_%'
            OR UPPER(p_table_name) LIKE '%_STG'
            OR UPPER(p_table_name) LIKE '%_STAGING'
            OR UPPER(p_table_name) LIKE 'STAGING_%'
            OR UPPER(p_table_name) LIKE '%_TEMP'
            OR UPPER(p_table_name) LIKE 'TEMP_%'
        THEN
            -- Try to find load timestamp column
            BEGIN
                SELECT column_name INTO p_load_column
                FROM all_tab_columns
                WHERE owner = p_owner
                AND table_name = p_table_name
                AND UPPER(column_name) IN ('LOAD_DTTM', 'LOAD_DATE', 'LOAD_TIMESTAMP', 'INSERT_DTTM', 'CREATED_DTTM', 'INGESTION_DTTM', 'CAPTURE_DTTM')
                AND data_type IN ('DATE', 'TIMESTAMP', 'TIMESTAMP(6)')
                ORDER BY
                    CASE UPPER(column_name)
                        WHEN 'LOAD_DTTM' THEN 1
                        WHEN 'LOAD_DATE' THEN 2
                        WHEN 'LOAD_TIMESTAMP' THEN 3
                        ELSE 4
                    END
                FETCH FIRST 1 ROW ONLY;

                RETURN TRUE;
            EXCEPTION
                WHEN NO_DATA_FOUND THEN
                    RETURN FALSE;
            END;
        END IF;

        RETURN FALSE;
    END detect_staging_table;


    -- ==========================================================================
    -- Public Functions
    -- ==========================================================================

    PROCEDURE analyze_column_distribution(
        p_owner VARCHAR2,
        p_table_name VARCHAR2,
        p_column_name VARCHAR2,
        p_distinct_values OUT NUMBER,
        p_null_percentage OUT NUMBER,
        p_distribution_type OUT VARCHAR2
    ) AS
        v_sql VARCHAR2(4000);
        v_total_rows NUMBER;
    BEGIN
        -- Get total rows
        v_sql := 'SELECT COUNT(*) FROM ' || p_owner || '.' || p_table_name;
        EXECUTE IMMEDIATE v_sql INTO v_total_rows;

        -- Get distinct values
        v_sql := 'SELECT COUNT(DISTINCT ' || p_column_name || ') FROM ' ||
                p_owner || '.' || p_table_name;
        EXECUTE IMMEDIATE v_sql INTO p_distinct_values;

        -- Get null percentage
        v_sql := 'SELECT ROUND(COUNT(*) * 100.0 / ' || v_total_rows || ', 2) FROM ' ||
                p_owner || '.' || p_table_name ||
                ' WHERE ' || p_column_name || ' IS NULL';
        EXECUTE IMMEDIATE v_sql INTO p_null_percentage;

        -- Classify distribution
        IF p_distinct_values = v_total_rows THEN
            p_distribution_type := 'UNIQUE';
        ELSIF p_distinct_values > v_total_rows * 0.9 THEN
            p_distribution_type := 'HIGH_CARDINALITY';
        ELSIF p_distinct_values > 100 THEN
            p_distribution_type := 'MEDIUM_CARDINALITY';
        ELSIF p_distinct_values BETWEEN 10 AND 100 THEN
            p_distribution_type := 'LOW_CARDINALITY';
        ELSE
            p_distribution_type := 'VERY_LOW_CARDINALITY';
        END IF;
    END analyze_column_distribution;


    FUNCTION recommend_partition_strategy(
        p_owner VARCHAR2,
        p_table_name VARCHAR2,
        p_reason OUT VARCHAR2
    ) RETURN VARCHAR2
    AS
        v_date_columns SYS.ODCIVARCHAR2LIST;
        v_min_date DATE;
        v_max_date DATE;
        v_range_days NUMBER;
        v_num_rows NUMBER;
        v_best_column VARCHAR2(128);
        v_max_range NUMBER := 0;
        v_strategy VARCHAR2(100);
        v_scd2_type VARCHAR2(30);
        v_scd2_column VARCHAR2(128);
        v_event_column VARCHAR2(128);
        v_staging_column VARCHAR2(128);
    BEGIN
        -- Get row count
        SELECT num_rows INTO v_num_rows
        FROM all_tables
        WHERE owner = p_owner
        AND table_name = p_table_name;

        -- Check for SCD2 pattern first
        IF detect_scd2_pattern(p_owner, p_table_name, v_scd2_type, v_scd2_column) THEN
            IF v_scd2_type = 'EFFECTIVE_DATE' THEN
                v_strategy := 'RANGE(' || v_scd2_column || ') INTERVAL YEARLY';
                p_reason := 'SCD2 table with effective_date pattern detected - yearly partitioning for historical tracking';
            ELSIF v_scd2_type = 'VALID_FROM_TO' THEN
                v_strategy := 'RANGE(' || v_scd2_column || ') INTERVAL YEARLY';
                p_reason := 'SCD2 table with valid_from_dttm/valid_to_dttm pattern detected - yearly partitioning for historical tracking';
            END IF;
            RETURN v_strategy;
        END IF;

        -- Check for EVENTS table pattern
        IF detect_events_table(p_owner, p_table_name, v_event_column) THEN
            IF UPPER(p_table_name) LIKE '%AUDIT%' OR UPPER(p_table_name) LIKE '%COMPLIANCE%' THEN
                v_strategy := 'RANGE(' || v_event_column || ') INTERVAL MONTHLY';
                p_reason := 'Audit/compliance events table detected - monthly partitioning for long-term retention';
            ELSE
                v_strategy := 'RANGE(' || v_event_column || ') INTERVAL DAILY';
                p_reason := 'Events table detected - daily partitioning for high-volume event data';
            END IF;
            RETURN v_strategy;
        END IF;

        -- Check for STAGING table pattern
        IF detect_staging_table(p_owner, p_table_name, v_staging_column) THEN
            v_strategy := 'RANGE(' || v_staging_column || ') INTERVAL DAILY';
            p_reason := 'Staging table detected - daily partitioning for easy partition exchange and purging';
            RETURN v_strategy;
        END IF;

        -- Note: Detection of non-standard date formats (NUMBER, VARCHAR) is handled
        -- in the analyze_table procedure and stored in dwh_migration_analysis table

        -- Get date columns for general analysis
        v_date_columns := get_date_columns(p_owner, p_table_name);

        -- Analyze each date column
        IF v_date_columns IS NOT NULL AND v_date_columns.COUNT > 0 THEN
            FOR i IN 1..v_date_columns.COUNT LOOP
                IF analyze_date_column(
                    p_owner, p_table_name, v_date_columns(i),
                    v_min_date, v_max_date, v_range_days
                ) THEN
                    IF v_range_days > v_max_range THEN
                        v_max_range := v_range_days;
                        v_best_column := v_date_columns(i);
                    END IF;
                END IF;
            END LOOP;

            -- Recommend strategy based on date range
            IF v_best_column IS NOT NULL THEN
                IF v_max_range > 365 * 3 THEN
                    v_strategy := 'RANGE(' || v_best_column || ') INTERVAL MONTHLY';
                    p_reason := 'Date range spans ' || ROUND(v_max_range/365, 1) ||
                               ' years - monthly interval partitioning recommended';
                ELSIF v_max_range > 365 THEN
                    v_strategy := 'RANGE(' || v_best_column || ') INTERVAL MONTHLY';
                    p_reason := 'Date range spans ' || ROUND(v_max_range/30, 0) ||
                               ' months - monthly partitioning recommended';
                ELSIF v_max_range > 90 THEN
                    v_strategy := 'RANGE(' || v_best_column || ')';
                    p_reason := 'Date range spans ' || v_max_range ||
                               ' days - range partitioning recommended';
                ELSE
                    v_strategy := NULL;
                    p_reason := 'Date range too small for effective partitioning';
                END IF;

                RETURN v_strategy;
            END IF;
        END IF;

        -- No suitable date column, recommend hash partitioning for large tables
        IF v_num_rows > 10000000 THEN
            -- Find primary key or first indexed column
            BEGIN
                SELECT cc.column_name INTO v_best_column
                FROM all_constraints c
                JOIN all_cons_columns cc
                    ON cc.owner = c.owner
                    AND cc.constraint_name = c.constraint_name
                WHERE c.owner = p_owner
                AND c.table_name = p_table_name
                AND c.constraint_type = 'P'
                AND ROWNUM = 1;

                v_strategy := 'HASH(' || v_best_column || ') PARTITIONS 16';
                p_reason := 'Large table (' || v_num_rows || ' rows) without date column - hash partitioning for even distribution';
                RETURN v_strategy;
            EXCEPTION
                WHEN NO_DATA_FOUND THEN
                    NULL;
            END;
        END IF;

        -- No partitioning recommended
        v_strategy := NULL;
        p_reason := 'Table not suitable for partitioning - no date columns and not large enough for hash';
        RETURN v_strategy;

    EXCEPTION
        WHEN OTHERS THEN
            p_reason := 'Error during analysis: ' || SQLERRM;
            RETURN NULL;
    END recommend_partition_strategy;


    FUNCTION estimate_partition_count(
        p_owner VARCHAR2,
        p_table_name VARCHAR2,
        p_partition_key VARCHAR2,
        p_partition_type VARCHAR2
    ) RETURN NUMBER
    AS
        v_sql VARCHAR2(4000);
        v_distinct_values NUMBER;
        v_min_date DATE;
        v_max_date DATE;
        v_months NUMBER;
    BEGIN
        IF p_partition_type LIKE 'RANGE%' THEN
            -- For range partitioning on dates
            v_sql := 'SELECT MIN(' || p_partition_key || '), MAX(' || p_partition_key || ')' ||
                    ' FROM ' || p_owner || '.' || p_table_name;

            EXECUTE IMMEDIATE v_sql INTO v_min_date, v_max_date;

            v_months := MONTHS_BETWEEN(v_max_date, v_min_date);
            RETURN CEIL(v_months);

        ELSIF p_partition_type LIKE 'HASH%' THEN
            -- For hash partitioning, return recommended partition count
            RETURN 16;

        ELSIF p_partition_type LIKE 'LIST%' THEN
            -- For list partitioning, return distinct values
            v_sql := 'SELECT COUNT(DISTINCT ' || p_partition_key || ')' ||
                    ' FROM ' || p_owner || '.' || p_table_name;

            EXECUTE IMMEDIATE v_sql INTO v_distinct_values;
            RETURN LEAST(v_distinct_values, 100);  -- Cap at 100 partitions

        ELSE
            RETURN 1;
        END IF;

    EXCEPTION
        WHEN OTHERS THEN
            RETURN 0;
    END estimate_partition_count;


    FUNCTION calculate_complexity_score(
        p_owner VARCHAR2,
        p_table_name VARCHAR2
    ) RETURN NUMBER
    AS
        v_score NUMBER := 0;
        v_count NUMBER;
    BEGIN
        -- Base complexity
        v_score := 1;

        -- Add points for indexes
        SELECT COUNT(*) INTO v_count
        FROM all_indexes
        WHERE table_owner = p_owner
        AND table_name = p_table_name;
        v_score := v_score + LEAST(v_count * 0.5, 3);

        -- Add points for constraints
        SELECT COUNT(*) INTO v_count
        FROM all_constraints
        WHERE owner = p_owner
        AND table_name = p_table_name
        AND constraint_type IN ('R', 'C', 'U');
        v_score := v_score + LEAST(v_count * 0.3, 2);

        -- Add points for foreign keys
        SELECT COUNT(*) INTO v_count
        FROM all_constraints
        WHERE owner = p_owner
        AND table_name = p_table_name
        AND constraint_type = 'R';
        IF v_count > 0 THEN
            v_score := v_score + 2;
        END IF;

        -- Add points for triggers
        SELECT COUNT(*) INTO v_count
        FROM all_triggers
        WHERE table_owner = p_owner
        AND table_name = p_table_name;
        v_score := v_score + v_count;

        -- Add points for LOBs
        SELECT COUNT(*) INTO v_count
        FROM all_tab_columns
        WHERE owner = p_owner
        AND table_name = p_table_name
        AND data_type IN ('CLOB', 'BLOB', 'NCLOB');
        IF v_count > 0 THEN
            v_score := v_score + 1;
        END IF;

        RETURN LEAST(v_score, 10);  -- Cap at 10
    END calculate_complexity_score;


    FUNCTION get_dependent_objects(
        p_owner VARCHAR2,
        p_table_name VARCHAR2
    ) RETURN CLOB
    AS
        v_result CLOB;
        v_count NUMBER;
    BEGIN
        DBMS_LOB.CREATETEMPORARY(v_result, TRUE);

        DBMS_LOB.APPEND(v_result, '{');

        -- Indexes
        SELECT COUNT(*) INTO v_count
        FROM all_indexes
        WHERE table_owner = p_owner AND table_name = p_table_name;
        DBMS_LOB.APPEND(v_result, '"indexes": ' || v_count || ',');

        -- Constraints
        SELECT COUNT(*) INTO v_count
        FROM all_constraints
        WHERE owner = p_owner AND table_name = p_table_name;
        DBMS_LOB.APPEND(v_result, '"constraints": ' || v_count || ',');

        -- Triggers
        SELECT COUNT(*) INTO v_count
        FROM all_triggers
        WHERE table_owner = p_owner AND table_name = p_table_name;
        DBMS_LOB.APPEND(v_result, '"triggers": ' || v_count || ',');

        -- Foreign keys referencing this table
        SELECT COUNT(*) INTO v_count
        FROM all_constraints
        WHERE r_owner = p_owner
        AND r_constraint_name IN (
            SELECT constraint_name FROM all_constraints
            WHERE owner = p_owner AND table_name = p_table_name
            AND constraint_type = 'P'
        );
        DBMS_LOB.APPEND(v_result, '"referenced_by": ' || v_count);

        DBMS_LOB.APPEND(v_result, '}');

        RETURN v_result;
    END get_dependent_objects;


    FUNCTION identify_blocking_issues(
        p_owner VARCHAR2,
        p_table_name VARCHAR2
    ) RETURN CLOB
    AS
        v_issues CLOB;
        v_count NUMBER;
        v_first BOOLEAN := TRUE;
    BEGIN
        DBMS_LOB.CREATETEMPORARY(v_issues, TRUE);
        DBMS_LOB.APPEND(v_issues, '[');

        -- Check for materialized views
        SELECT COUNT(*) INTO v_count
        FROM all_mviews
        WHERE owner = p_owner
        AND mview_name = p_table_name;

        IF v_count > 0 THEN
            IF NOT v_first THEN DBMS_LOB.APPEND(v_issues, ','); END IF;
            DBMS_LOB.APPEND(v_issues,
                '{"type": "ERROR", "issue": "Table is a materialized view", ' ||
                '"action": "Cannot partition materialized views directly"}');
            v_first := FALSE;
        END IF;

        -- Check for IOTs
        SELECT COUNT(*) INTO v_count
        FROM all_tables
        WHERE owner = p_owner
        AND table_name = p_table_name
        AND iot_type IS NOT NULL;

        IF v_count > 0 THEN
            IF NOT v_first THEN DBMS_LOB.APPEND(v_issues, ','); END IF;
            DBMS_LOB.APPEND(v_issues,
                '{"type": "ERROR", "issue": "Table is an Index-Organized Table", ' ||
                '"action": "IOT partitioning requires special handling"}');
            v_first := FALSE;
        END IF;

        DBMS_LOB.APPEND(v_issues, ']');
        RETURN v_issues;
    END identify_blocking_issues;


    -- ==========================================================================
    -- Main Analysis Procedures
    -- ==========================================================================

    PROCEDURE analyze_table(
        p_task_id NUMBER
    ) AS
        v_task dwh_migration_tasks%ROWTYPE;
        v_analysis_id NUMBER;
        v_reason VARCHAR2(1000);
        v_recommended_strategy VARCHAR2(100);
        v_complexity NUMBER;
        v_partition_count NUMBER;
        v_table_size NUMBER;
        v_dependent_objects CLOB;
        v_blocking_issues CLOB;
        v_num_rows NUMBER;
        v_date_column VARCHAR2(128);
        v_date_format VARCHAR2(50);
        v_date_type VARCHAR2(30);
        v_conversion_expr VARCHAR2(500);
        v_requires_conversion CHAR(1) := 'N';
    BEGIN
        -- Get task details
        SELECT * INTO v_task
        FROM dwh_migration_tasks
        WHERE task_id = p_task_id
        FOR UPDATE;

        DBMS_OUTPUT.PUT_LINE('Analyzing table: ' || v_task.source_owner || '.' || v_task.source_table);

        -- Update task status
        UPDATE dwh_migration_tasks
        SET status = 'ANALYZING', analysis_date = SYSTIMESTAMP
        WHERE task_id = p_task_id;
        COMMIT;

        -- Get table statistics
        SELECT num_rows INTO v_num_rows
        FROM all_tables
        WHERE owner = v_task.source_owner
        AND table_name = v_task.source_table;

        v_table_size := get_table_size_mb(v_task.source_owner, v_task.source_table);

        -- Check for non-standard date formats (NUMBER or VARCHAR-based dates)
        IF detect_numeric_date_column(v_task.source_owner, v_task.source_table, v_date_column, v_date_format) THEN
            v_requires_conversion := 'Y';
            v_date_type := 'NUMBER';
            v_conversion_expr := get_date_conversion_expr(v_date_column, 'NUMBER', v_date_format);
            DBMS_OUTPUT.PUT_LINE('Detected NUMBER-based date column: ' || v_date_column || ' (Format: ' || v_date_format || ')');
        ELSIF detect_varchar_date_column(v_task.source_owner, v_task.source_table, v_date_column, v_date_format) THEN
            v_requires_conversion := 'Y';
            v_date_type := 'VARCHAR2';
            v_conversion_expr := get_date_conversion_expr(v_date_column, 'VARCHAR2', v_date_format);
            DBMS_OUTPUT.PUT_LINE('Detected VARCHAR-based date column: ' || v_date_column || ' (Format: ' || v_date_format || ')');
        END IF;

        -- Recommend partitioning strategy if not specified
        IF v_task.partition_type IS NULL THEN
            v_recommended_strategy := recommend_partition_strategy(
                v_task.source_owner,
                v_task.source_table,
                v_reason
            );

            -- If non-standard date format detected and no strategy found, suggest conversion
            IF v_requires_conversion = 'Y' AND v_recommended_strategy IS NULL THEN
                v_recommended_strategy := 'RANGE(' || v_date_column || '_CONVERTED) INTERVAL MONTHLY';
                v_reason := 'Date column ' || v_date_column || ' stored as ' || v_date_type ||
                           ' (format: ' || v_date_format || ') - conversion to DATE recommended for partitioning';
            END IF;
        ELSE
            v_recommended_strategy := v_task.partition_type;
            v_reason := 'Strategy specified by user';
        END IF;

        -- Calculate complexity
        v_complexity := calculate_complexity_score(v_task.source_owner, v_task.source_table);

        -- Estimate partition count
        IF v_task.partition_key IS NOT NULL AND v_recommended_strategy IS NOT NULL THEN
            v_partition_count := estimate_partition_count(
                v_task.source_owner,
                v_task.source_table,
                v_task.partition_key,
                v_recommended_strategy
            );
        END IF;

        -- Get dependencies
        v_dependent_objects := get_dependent_objects(v_task.source_owner, v_task.source_table);
        v_blocking_issues := identify_blocking_issues(v_task.source_owner, v_task.source_table);

        -- Store analysis results
        INSERT INTO dwh_migration_analysis (
            task_id,
            table_rows,
            table_size_mb,
            recommended_strategy,
            recommendation_reason,
            date_column_name,
            date_column_type,
            date_format_detected,
            date_conversion_expr,
            requires_conversion,
            estimated_partitions,
            avg_partition_size_mb,
            estimated_compression_ratio,
            estimated_space_savings_mb,
            complexity_score,
            dependent_objects,
            blocking_issues
        ) VALUES (
            p_task_id,
            v_num_rows,
            v_table_size,
            v_recommended_strategy,
            v_reason,
            v_date_column,
            v_date_type,
            v_date_format,
            v_conversion_expr,
            v_requires_conversion,
            v_partition_count,
            CASE WHEN v_partition_count > 0 THEN v_table_size / v_partition_count ELSE 0 END,
            CASE WHEN v_task.use_compression = 'Y' THEN 4 ELSE 1 END,  -- Estimate 4:1 compression
            CASE WHEN v_task.use_compression = 'Y' THEN v_table_size * 0.75 ELSE 0 END,
            v_complexity,
            v_dependent_objects,
            v_blocking_issues
        ) RETURNING analysis_id INTO v_analysis_id;

        -- Update task
        UPDATE dwh_migration_tasks
        SET status = 'ANALYZED',
            source_rows = v_num_rows,
            source_size_mb = v_table_size,
            validation_status = CASE
                WHEN DBMS_LOB.INSTR(v_blocking_issues, 'ERROR') > 0 THEN 'BLOCKED'
                ELSE 'READY'
            END
        WHERE task_id = p_task_id;

        COMMIT;

        DBMS_OUTPUT.PUT_LINE('Analysis complete:');
        DBMS_OUTPUT.PUT_LINE('  Recommended strategy: ' || NVL(v_recommended_strategy, 'NONE'));
        DBMS_OUTPUT.PUT_LINE('  Complexity score: ' || v_complexity || '/10');
        DBMS_OUTPUT.PUT_LINE('  Estimated partitions: ' || NVL(v_partition_count, 0));

    EXCEPTION
        WHEN OTHERS THEN
            UPDATE dwh_migration_tasks
            SET status = 'FAILED',
                error_message = 'Analysis failed: ' || SQLERRM
            WHERE task_id = p_task_id;
            COMMIT;
            RAISE;
    END analyze_table;


    PROCEDURE analyze_all_pending_tasks(
        p_project_id NUMBER DEFAULT NULL
    ) AS
        v_count NUMBER := 0;
    BEGIN
        FOR task IN (
            SELECT task_id, source_owner, source_table
            FROM dwh_migration_tasks
            WHERE (p_project_id IS NULL OR project_id = p_project_id)
            AND status IN ('PENDING', 'READY')
            ORDER BY task_id
        ) LOOP
            BEGIN
                analyze_table(task.task_id);
                v_count := v_count + 1;
            EXCEPTION
                WHEN OTHERS THEN
                    DBMS_OUTPUT.PUT_LINE('ERROR analyzing ' || task.source_table || ': ' || SQLERRM);
            END;
        END LOOP;

        DBMS_OUTPUT.PUT_LINE('Analyzed ' || v_count || ' task(s)');
    END analyze_all_pending_tasks;

END dwh_table_migration_analyzer;
/

SELECT 'Table Migration Analyzer Package Created Successfully!' AS status FROM DUAL;
